package com.terrapay.demoproject.LibraryManagementSystem.service;


import com.terrapay.demoproject.LibraryManagementSystem.model.TextBooks;
import com.terrapay.demoproject.LibraryManagementSystem.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


@Service
public class BookServiceImpl implements BookService

{

    @Autowired
    private BookRepository bookRepository;

    @Override
    public List<TextBooks> fetchTextBooksList()

    {

        return bookRepository.findAll();

    }

    @Override
    public TextBooks saveBook(TextBooks textBooks)

    {

        return bookRepository.save(textBooks);

    }

    @Override
    public Optional<TextBooks> fetchTextBooksById(Long textbooksId)

    {

        return bookRepository.findById(textbooksId);
    }

    @Override
    public void deleteBookById(Long bookId)

    {
        bookRepository.deleteById(bookId);

    }


}
